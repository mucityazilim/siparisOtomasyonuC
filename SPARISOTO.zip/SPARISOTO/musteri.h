#ifndef _MUSTERI_H
#define _MUSTERI_H
typedef struct Musteri {
	int ID; 
	char adSoyad[30], cinsiyet, adres[30], tel[20], eposta[30]; 
} musteri ;

void musteriEkle(); 
void musteriListele(); 
void musteriGuncelle(); 
void musteriSil(); 
int musteriMenu(); 
void musteriIslemleri(); 




#endif 
