#include "siparis.h"
#include "musteri.h"
#include "urun.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

 
siparis s1, s2; 
musteri m1; 
urun u1; 

int musteriKontrolu(int mID  )
{
	
	int durum=0 ; 
	
	
	FILE *ptr= fopen("musteriler.dat", "r+b") ; 
	while( fread ( &m1, sizeof(musteri), 1, ptr )  !=NULL  )
	{
		if( mID== m1.ID ) 
		{
			durum =1; 
			break; 
		}		
	}
	return durum ; 	
		
	
 } 
int urunKontrolu(int uID, int adet  )
{
	int durum=0 ; 

	FILE *ptr= fopen("urunler.dat", "r+b") ; 
	while( fread ( &u1, sizeof(urun), 1, ptr )  !=NULL  )
	{
		if( uID == u1.ID ) 
		{
			durum =1; 
			if( u1.urunAdet < adet  ) 
			durum = -1 ; 
			
			break; 
		}
		
   }
   if(durum==1 ) 
   return u1.birimFiyat ; 
   else 
   return durum ; 
   
 
	
}


void urunStokGuncelle(int urunID, int sayi  )
{
	int sayac=0; 
	FILE *ptr= fopen("urunler.dat", "r+b") ; 
	while( fread ( &u1, sizeof(urun), 1, ptr )  !=NULL  )
	{
		if( urunID == u1.ID ) 
		break; 
		sayac++; 		
	}
	
	fseek( ptr, (sayac) * sizeof(urun ), 0 ) ;
	u1.urunAdet += sayi; 
	fwrite ( &u1, sizeof(urun ), 1, ptr ) ; 
	fclose(ptr) ; 
	
	
}
void siparisOlustur()
{
	system("cls"); 
	printf("Siparis olusturma ekrani... \n\n") ; 
	
	FILE * numPtr = fopen("siparisNumaralari.dat", "a+b" ) ; 
	int numara=0; 
	while( fread ( &numara, sizeof(int), 1, numPtr ) !=NULL  ) 
	{
		
	}
	numara++; 
	fwrite  ( &numara, sizeof(int), 1, numPtr ) ;
	fclose(numPtr);
	 
	s1.ID= numara; 	
	
	system("cls"); 
	printf("Musteri listesi... \n\n") ; 
	
	int sayac=0,  durum=0 ; 
	printf("%-10s%-30s%-10s%-30s%-20s%-30s\n", "NUMARA", "AD-SOYAD", "CINSIYET", "ADRES", "TELEFON", "e-POSTA" ) ; 
	
	FILE *ptr= fopen("musteriler.dat", "r+b") ; 
	while( fread ( &m1, sizeof(musteri), 1, ptr )  !=NULL  )
	{
		printf("%-10d%-30s%-10c%-30s%-20s%-30s\n", m1.ID, m1.adSoyad, m1.cinsiyet, m1.adres, m1.tel, m1.eposta ); 
		sayac++; 		
	}
	if( sayac==0)
	{
	system("cls") ;  
	printf("Musteri kaydi yok ! \n") ; 	
	printf("Sparis kaydinda once musteri kaydi yapiniz... ")  ; 
	}
	else
	{
		printf("Musteri ID  : ") ; scanf(" %d", &s1.mID ) ;	
		
		system("cls"); 
		printf("Urun listesi... \n\n") ; 
	
		sayac=0, durum=0 ; 
		printf("%-10s%-30s%-20s%-10s\n", "NUMARA", "URUN ADI", "FIYAT (TL)", "ADET "  ) ; 
		fclose(ptr) ; 
		ptr= fopen("urunler.dat", "r+b") ; 
		while( fread ( &u1, sizeof(urun), 1, ptr )  !=NULL  )
		{
			if(u1.urunAdet>0)
			printf("%-10d%-30s%-20d%-10d\n", u1.ID, u1.urunAdi, u1.birimFiyat, u1.urunAdet   ) ;  
			sayac++; 		
		}
		if( sayac==0)
		{
		system("cls") ;  
		printf("Stokta hic urun yok ! \n") ; 
		}
		else
		{	
		fclose(ptr); 
		printf("Urun ID  : ") ; scanf(" %d", &s1.uID ) ;	
		
		system("cls");
		printf("Adet  : ") ; scanf(" %d", &s1.adet ) ; 
		int mSonuc= musteriKontrolu(s1.mID);
		int uSonuc=urunKontrolu(s1.uID, s1.adet ); 
		
		if( mSonuc==0 ) 
		{
			printf("Hatali islem yaptiniz, lutfen bilgileri tekrar gozden geciriniz.... ! ") ; 
		}
		else if( uSonuc==0 ) 
		{
			printf("Hatali islem yaptiniz, lutfen bilgileri tekrar gozden geciriniz.... ! ") ; 			
		}
		else if ( uSonuc==-1 ) 
		{
			printf("Stokta yeterli miktarda urun yok ! \n") ; 
		}
		else
		{
			fclose(ptr); 
			s1.toplamUcret= s1.adet *uSonuc; 
			time_t tarih = time(NULL); 
			strcpy(s1.tarih, ctime(&tarih )     ) ; 
			
			
			ptr= fopen( "siparisler.dat", "a+b" ) ; 
			fwrite ( &s1, sizeof(siparis ), 1, ptr ) ; 
			fclose(ptr)  ; 
			system("cls") ; 
			printf("%d numarali sparis kaydi tamam \n", numara  ) ; 			
			printf("%-10d%-10d%-10d%-10d%-10d%-30s \n", s1.ID, s1.mID, s1.uID, s1.adet, s1.toplamUcret, s1.tarih ); 
			urunStokGuncelle(s1.uID, -s1.adet) ; 
			
		}
		} 		
	}
		 
	 
	fclose(ptr) ; 
	
}
 
void siparisIptalet ()
{
	system("cls"); 
	printf("Siparis listesi... \n\n") ; 
	
	int sayac=0, numara, durum=0 ; 

	printf("%-10s%-10s%-10s%-10s%-10s%-30s \n", "NUMARA", "MUST-ID", "URUN-ID", "ADET", "T-UCRET", "TARIH"  ) ; 
			
	FILE *ptr= fopen("siparisler.dat", "r+b") ; 
	while( fread ( &s1, sizeof(siparis), 1, ptr )  !=NULL  )
	{
		printf("%-10d%-10d%-10d%-10d%-10d%-30s \n", s1.ID, s1.mID, s1.uID, s1.adet, s1.toplamUcret, s1.tarih ); 
		sayac++; 		
	}
	
	if( sayac==0)
	{
	system("cls") ;  
	printf("Siparis kaydi yok ! \n") ; 	
	}
	else
	{
		sayac=0; 
		rewind(ptr); 
		printf("\niptal etmek  istediginiz siparis numarasini giriniz  : ");  scanf("%d", &numara) ; 
		while( fread ( &s1, sizeof(siparis ), 1, ptr )  !=NULL  )
		{
			if( numara == s1.ID ) 
			{
				durum =1; 
				break; 
			}
			sayac++;  		
		}
		if( durum==0)
		printf("\n%d numarali siparis kaydi bulunamadi ! \n", numara ); 
		else
		{
			char tercih; 
			rewind(ptr); 
			system("cls") ; 
			
		printf("%-10s%-10s%-10s%-10s%-10s%-30s \n", "NUMARA", "MUST-ID", "URUN-ID", "ADET", "T-UCRET", "TARIH"  ) ; 
		printf("%-10d%-10d%-10d%-10d%-10d%-30s \n", s1.ID, s1.mID, s1.uID, s1.adet, s1.toplamUcret, s1.tarih ); 
			
			printf("\n%d Numarali siparis kaydini iptal etmek  istediginize emin misiniz ? (E/H)  : ") ; scanf(" %c", &tercih ) ; 
			
			if( tercih =='e' || tercih =='E' ) 
			{
				FILE *yedekPtr= fopen("yedek.dat", "w+b") ; 
				while( fread ( &s1, sizeof(siparis ), 1, ptr )  !=NULL  )
				{
					if( numara != s1.ID ) 
					{
						fwrite ( &s1, sizeof(siparis ), 1, yedekPtr ) ; 						
					}
				}
				
				fclose(yedekPtr ) ; 
				fclose(ptr)  ; 
				remove("siparisler.dat") ; 
				rename("yedek.dat", "siparisler.dat" ) ; 				
				system("cls") ; 				
	 			printf("\n%d numarali siparis kaydi iptal edildi  \n", numara ); 
	 			urunStokGuncelle(s1.uID, s1.adet) ; 
			
		
			}
			else 
			printf("\nSiparis iptal etme  islemi iptal edildi \n") ; 
			
		}		
	 } 
	fclose(ptr) ; 
	
	
	
}

void siparisleriRaporla ()
{
	system("cls"); 
	printf("Sparisleri Raporlama ekrani... \n\n") ; 
	
	int sayac=0; 
	printf("%-10s%-10s%-10s%-10s%-10s%-30s \n", "NUMARA", "MUST-ID", "URUN-ID", "ADET", "T-UCRET", "TARIH"  ) ; 
	
	FILE *ptr= fopen("siparisler.dat", "r+b") ; 
	while( fread ( &s1, sizeof(siparis ), 1, ptr )  !=NULL  )
	{
		printf("%-10d%-10d%-10d%-10d%-10d%-30s \n", s1.ID, s1.mID, s1.uID, s1.adet, s1.toplamUcret, s1.tarih ); 
		sayac++; 		
	}
	fclose(ptr) ;
	if( sayac==0)
	{
	system("cls") ;  
	printf("Siparis kaydi yok ! \n") ; 	
	}
	else 
	printf("\nToplam Siparis Sayisi : %d  \n", sayac   ) ;  	
	
	
	
}


int  siparisMenu()
{
	int secim; 
	printf("\n\tSiparis Islemleri \n\n") ; 
	printf("\t1- Siparis Olustur  \n");
	printf("\t2- Siparis Iptalet  \n");
	printf("\t3- Siparisleri Listele  \n");
	printf("\t0- Anamenuye don \n") ; 
	printf("\n\tSeciminiz  :  ") ; scanf("%d", &secim); 
	system("cls"); 
	return secim;
	
}
void siparisIslemleri()
{
	int secim= siparisMenu(); 
	while( secim != 0)
	{
		switch(secim )
		{
			case 1: siparisOlustur() ; break;
			case 2: siparisIptalet() ; break;
			case 3: siparisleriRaporla () ; break;
			
			case 0: printf("Anamenuye yonlendiriyorsunuz... ") ; break; 
			default: printf("hatali islem ! \n") ; break; 
		}
		secim= siparisMenu(); 
	} 	
	
}
