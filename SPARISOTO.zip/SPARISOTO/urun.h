#ifndef _URUN_H
#define _URUN_H

typedef struct Urun {
	int ID; 
	char urunAdi[30]; 
	int birimFiyat, urunAdet;  
} urun  ;

void urunEkle(); 
void urunListele(); 
void urunGuncelle(); 
void urunSil(); 
int  urunMenu(); 
void urunIslemleri(); 


#endif 
