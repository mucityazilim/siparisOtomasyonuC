#include "musteri.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

musteri m1, m2 ; 



void musteriEkle()
{
	system("cls"); 
	printf("Musteri ekleme ekrani... \n\n") ; 
	
	FILE * numPtr = fopen("musteriNumaralari.dat", "a+b" ) ; 
	int numara=0; 
	while( fread ( &numara, sizeof(int), 1, numPtr ) !=NULL  ) 
	{
		
	}
	numara++; 
	fwrite  ( &numara, sizeof(int), 1, numPtr ) ;
	fclose(numPtr);
	 
	m1.ID= numara; 	
	printf("Ad-Soyad : ") ; scanf(" %[^\n]s", m1.adSoyad ) ; 
	printf("Cinsiyet : ") ; scanf(" %[^\n]s", &m1.cinsiyet ) ; 
	printf("Adres    : ") ; scanf(" %[^\n]s", m1.adres ) ; 
	printf("Telefon  : ") ; scanf(" %[^\n]s", m1.tel ) ; 
	printf("e-posta  : ") ; scanf(" %[^\n]s", m1.eposta ) ; 
	
	FILE *ptr= fopen("musteriler.dat", "a+b") ; 
	fwrite ( &m1, sizeof(musteri), 1, ptr ) ; 
	fclose(ptr) ;
	
	system("cls") ;  
	printf("%d numarali Musteri kaydi tamam \n", numara  ) ;  	
}
void musteriListele()
{
	system("cls"); 
	printf("Musteri listeleme ekrani... \n\n") ; 
	
	int sayac=0; 
	printf("%-10s%-30s%-10s%-30s%-20s%-30s\n", "NUMARA", "AD-SOYAD", "CINSIYET", "ADRES", "TELEFON", "e-POSTA" ) ; 
	
	FILE *ptr= fopen("musteriler.dat", "r+b") ; 
	while( fread ( &m1, sizeof(musteri), 1, ptr )  !=NULL  )
	{
		printf("%-10d%-30s%-10c%-30s%-20s%-30s\n", m1.ID, m1.adSoyad, m1.cinsiyet, m1.adres, m1.tel, m1.eposta ); 
		sayac++; 		
	}
	fclose(ptr) ;
	if( sayac==0)
	{
	system("cls") ;  
	printf("Kayitli musteri yok ! \n") ; 	
	}
	else 
	printf("\nToplam musteri sayisi : %d  \n", sayac   ) ;  	
}

	

void musteriGuncelle()
{
	system("cls"); 
	printf("Musteri listesi... \n\n") ; 
	
	int sayac=0, numara, durum=0 ; 
	printf("%-10s%-30s%-10s%-30s%-20s%-30s\n", "NUMARA", "AD-SOYAD", "CINSIYET", "ADRES", "TELEFON", "e-POSTA" ) ; 
	
	FILE *ptr= fopen("musteriler.dat", "r+b") ; 
	while( fread ( &m1, sizeof(musteri), 1, ptr )  !=NULL  )
	{
		printf("%-10d%-30s%-10c%-30s%-20s%-30s\n", m1.ID, m1.adSoyad, m1.cinsiyet, m1.adres, m1.tel, m1.eposta ); 
		sayac++; 		
	}
	if( sayac==0)
	{
	system("cls") ;  
	printf("Musteri kaydi yok ! \n") ; 	
	}
	else
	{
		sayac=0; 
		rewind(ptr); 
		printf("\nGuncellemek istediginiz musteri numarasi : ");  scanf("%d", &numara) ; 
		while( fread ( &m1, sizeof(musteri), 1, ptr )  !=NULL  )
		{
			if( numara == m1.ID ) 
			{
				durum =1; 
				break; 
			}
			sayac++;  		
		}
		if( durum==0)
		printf("\n%d numarali musteri kaydi bulunamadi ! \n", numara ); 
		else
		{
			rewind(ptr); 
			system("cls") ; 
			printf("%-10s%-30s%-10s%-30s%-20s%-30s\n", "NUMARA", "AD-SOYAD", "CINSIYET", "ADRES", "TELEFON", "e-POSTA" ) ; 
			printf("%-10d%-30s%-10c%-30s%-20s%-30s\n", m1.ID, m1.adSoyad, m1.cinsiyet, m1.adres, m1.tel, m1.eposta ); 
			printf("\nGuncellemek istediginiz verileri tekrar giriniz \n") ; 
			
			printf("Ad-Soyad : ") ; scanf(" %[^\n]s", m1.adSoyad ) ; 
			printf("Cinsiyet : ") ; scanf(" %[^\n]s", &m1.cinsiyet ) ; 
			printf("Adres    : ") ; scanf(" %[^\n]s", m1.adres ) ; 
			printf("Telefon  : ") ; scanf(" %[^\n]s", m1.tel ) ; 
			printf("e-posta  : ") ; scanf(" %[^\n]s", m1.eposta ) ;
			
			fseek( ptr, (sayac) * sizeof(musteri), 0 ) ; 
			fwrite ( &m1, sizeof(musteri), 1, ptr ) ; 
			system("cls") ; 
 			printf("\n%d numarali musteri kaydi guncellendi \n", numara ); 

		}		
	 } 
	fclose(ptr) ; 
}
void musteriSil()
{
	system("cls"); 
	printf("Musteri listesi... \n\n") ; 
	
	int sayac=0, numara, durum=0 ; 
	printf("%-10s%-30s%-10s%-30s%-20s%-30s\n", "NUMARA", "AD-SOYAD", "CINSIYET", "ADRES", "TELEFON", "e-POSTA" ) ; 
	
	FILE *ptr= fopen("musteriler.dat", "r+b") ; 
	while( fread ( &m1, sizeof(musteri), 1, ptr )  !=NULL  )
	{
		printf("%-10d%-30s%-10c%-30s%-20s%-30s\n", m1.ID, m1.adSoyad, m1.cinsiyet, m1.adres, m1.tel, m1.eposta ); 
		sayac++; 		
	}
	if( sayac==0)
	{
	system("cls") ;  
	printf("Musteri kaydi yok ! \n") ; 	
	}
	else
	{
		sayac=0; 
		rewind(ptr); 
		printf("\nSilmek istediginiz musteri numarasini giriniz  : ");  scanf("%d", &numara) ; 
		while( fread ( &m1, sizeof(musteri), 1, ptr )  !=NULL  )
		{
			if( numara == m1.ID ) 
			{
				durum =1; 
				break; 
			}
			sayac++;  		
		}
		if( durum==0)
		printf("\n%d numarali musteri kaydi bulunamadi ! \n", numara ); 
		else
		{
			char tercih; 
			rewind(ptr); 
			system("cls") ; 
			printf("%-10s%-30s%-10s%-30s%-20s%-30s\n", "NUMARA", "AD-SOYAD", "CINSIYET", "ADRES", "TELEFON", "e-POSTA" ) ; 
			printf("%-10d%-30s%-10c%-30s%-20s%-30s\n", m1.ID, m1.adSoyad, m1.cinsiyet, m1.adres, m1.tel, m1.eposta ); 
			printf("\n%d Numarali musteriyi silmek istediginize emin misiniz ? (E/H)  : ") ; scanf(" %c", &tercih ) ; 
			
			if( tercih =='e' || tercih =='E' ) 
			{
				FILE *yedekPtr= fopen("yedek.dat", "w+b") ; 
				while( fread ( &m1, sizeof(musteri), 1, ptr )  !=NULL  )
				{
					if( numara != m1.ID ) 
					{
						fwrite ( &m1, sizeof(musteri), 1, yedekPtr ) ; 						
					}
				}
				
				fclose(yedekPtr ) ; 
				fclose(ptr)  ; 
				remove("musteriler.dat") ; 
				rename("yedek.dat", "musteriler.dat" ) ; 				
				system("cls") ; 				
	 			printf("\n%d numarali musteri kaydi silindi  \n", numara ); 
		
			}
			else 
			printf("\nSilme islemi iptal edildi \n") ; 
			
		}		
	 } 
	fclose(ptr) ; 
	
	
}
int musteriMenu()
{
	
	int secim; 
	printf("\n\tMusteri Islemleri \n\n") ; 
	printf("\t1- Musteri Ekle  \n");
	printf("\t2- Musteri Listele  \n");
	printf("\t3- Musteri Guncelle  \n");
	printf("\t4- Musteri Sil \n");
	
	printf("\t0- Anamenuye don \n") ; 
	printf("\n\tSeciminiz  :  ") ; scanf("%d", &secim); 
	system("cls"); 
	return secim;
	
	
}
void musteriIslemleri()
{
	
	int secim= musteriMenu(); 
	while( secim != 0)
	{
		switch(secim )
		{
			case 1: musteriEkle() ; break;
			case 2: musteriListele() ; break;
			case 3: musteriGuncelle () ; break;
			case 4: musteriSil ( ) ; break;
			
			case 0: printf("Anamenuye yonlendiriyorsunuz... ") ; break; 
			default: printf("hatali islem ! \n") ; break; 
		}
		secim= musteriMenu(); 
	}
	
}

