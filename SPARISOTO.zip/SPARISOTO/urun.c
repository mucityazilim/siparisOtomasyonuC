#include "urun.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
urun u1, u2; 


void urunEkle()
{
	system("cls"); 
	printf("Urun ekleme ekrani... \n\n") ; 
	
	FILE * numPtr = fopen("urunNumaralari.dat", "a+b" ) ; 
	int numara=0; 
	while( fread ( &numara, sizeof(int), 1, numPtr ) !=NULL  ) 
	{
		
	}
	numara++; 
	fwrite  ( &numara, sizeof(int), 1, numPtr ) ;
	fclose(numPtr);
	 
	u1.ID= numara; 	
	printf("Urun Adi    : ") ; scanf(" %[^\n]s", u1.urunAdi ) ; 
	printf("Birim Fiyat : ") ; scanf(" %d", &u1.birimFiyat ) ;
	printf("Urun Adet   : ") ; scanf(" %d", &u1.urunAdet ) ; 
	
	FILE *ptr= fopen("urunler.dat", "a+b") ; 
	fwrite ( &u1, sizeof(urun), 1, ptr ) ; 
	fclose(ptr) ;
	
	system("cls") ;  
	printf("%d numarali Urun kaydi tamam \n", numara  ) ;  		
	
}
void urunListele()
{
	system("cls"); 
	printf("Urun listeleme ekrani... \n\n") ; 
	
	int sayac=0; 
	printf("%-10s%-30s%-20s%-10s\n", "NUMARA", "URUN ADI", "FIYAT (TL)", "ADET "  ) ; 
	
	FILE *ptr= fopen("urunler.dat", "r+b") ; 
	while( fread ( &u1, sizeof(urun), 1, ptr )  !=NULL  )
	{
		printf("%-10d%-30s%-20d%-10d\n", u1.ID, u1.urunAdi, u1.birimFiyat, u1.urunAdet   ) ;  
		sayac++; 		
	}
	fclose(ptr) ;
	if( sayac==0)
	{
	system("cls") ;  
	printf("Urun kaydi yok ! \n") ; 	
	}
	else 
	printf("\nToplam urun cinsi sayisi : %d  \n", sayac   ) ;  	
	
}
void urunGuncelle()
{
	system("cls"); 
	printf("Urun listesi... \n\n") ; 
	
	int sayac=0, numara, durum=0 ; 
	printf("%-10s%-30s%-20s%-10s\n", "NUMARA", "URUN ADI", "FIYAT (TL)", "ADET "  ) ; 
	
	FILE *ptr= fopen("urunler.dat", "r+b") ; 
	while( fread ( &u1, sizeof(urun), 1, ptr )  !=NULL  )
	{
		printf("%-10d%-30s%-20d%-10d\n", u1.ID, u1.urunAdi, u1.birimFiyat, u1.urunAdet   ) ;  
		sayac++; 		
	}
	if( sayac==0)
	{
	system("cls") ;  
	printf("Urun kaydi yok ! \n") ; 	
	}
	else
	{
		sayac=0; 
		rewind(ptr); 
		printf("\nGuncellemek istediginiz urunun numarasi : ");  scanf("%d", &numara) ; 
		while( fread ( &u1, sizeof(urun ), 1, ptr )  !=NULL  )
		{
			if( numara == u1.ID ) 
			{
				durum =1; 
				break; 
			}
			sayac++;  		
		}
		if( durum==0)
		printf("\n%d numarali urun kaydi bulunamadi ! \n", numara ); 
		else
		{
			rewind(ptr); 
			system("cls") ; 
		
			printf("%-10s%-30s%-20s%-10s\n", "NUMARA", "URUN ADI", "FIYAT (TL)", "ADET "  ) ; 
			printf("%-10d%-30s%-20d%-10d\n", u1.ID, u1.urunAdi, u1.birimFiyat, u1.urunAdet   ) ;  

			printf("\nGuncellemek istediginiz verileri tekrar giriniz \n") ; 
			
			printf("Urun Adi    : ") ; scanf(" %[^\n]s", u1.urunAdi ) ; 
			printf("Birim Fiyat : ") ; scanf(" %d", &u1.birimFiyat ) ;
			printf("Urun Adet   : ") ; scanf(" %d", &u1.urunAdet ) ; 
			 
			
			fseek( ptr, (sayac) * sizeof(urun ), 0 ) ; 
			fwrite ( &u1, sizeof(urun ), 1, ptr ) ; 
			system("cls") ; 
 			printf("\n%d numarali urun kaydi guncellendi \n", numara ); 

		}		
	 } 
	fclose(ptr) ; 
	
}
void urunSil()
{
	system("cls"); 
	printf("Urun listesi... \n\n") ; 
	
	int sayac=0, numara, durum=0 ; 

	printf("%-10s%-30s%-20s%-10s\n", "NUMARA", "URUN ADI", "FIYAT (TL)", "ADET "  ) ; 
			
	FILE *ptr= fopen("urunler.dat", "r+b") ; 
	while( fread ( &u1, sizeof(urun), 1, ptr )  !=NULL  )
	{
		printf("%-10d%-30s%-20d%-10d\n", u1.ID, u1.urunAdi, u1.birimFiyat, u1.urunAdet   ) ;  
		sayac++; 		
	}
	
	if( sayac==0)
	{
	system("cls") ;  
	printf("Urun kaydi yok ! \n") ; 	
	}
	else
	{
		sayac=0; 
		rewind(ptr); 
		printf("\nSilmek istediginiz urun numarasini giriniz  : ");  scanf("%d", &numara) ; 
		while( fread ( &u1, sizeof(urun ), 1, ptr )  !=NULL  )
		{
			if( numara == u1.ID ) 
			{
				durum =1; 
				break; 
			}
			sayac++;  		
		}
		if( durum==0)
		printf("\n%d numarali urun kaydi bulunamadi ! \n", numara ); 
		else
		{
			char tercih; 
			rewind(ptr); 
			system("cls") ; 
			
		printf("%-10s%-30s%-20s%-10s\n", "NUMARA", "URUN ADI", "FIYAT (TL)", "ADET "  ) ; 
		printf("%-10d%-30s%-20d%-10d\n", u1.ID, u1.urunAdi, u1.birimFiyat, u1.urunAdet   ) ;  
			
			printf("\n%d Numarali urunu silmek istediginize emin misiniz ? (E/H)  : ") ; scanf(" %c", &tercih ) ; 
			
			if( tercih =='e' || tercih =='E' ) 
			{
				FILE *yedekPtr= fopen("yedek.dat", "w+b") ; 
				while( fread ( &u1, sizeof(urun ), 1, ptr )  !=NULL  )
				{
					if( numara != u1.ID ) 
					{
						fwrite ( &u1, sizeof(urun ), 1, yedekPtr ) ; 						
					}
				}
				
				fclose(yedekPtr ) ; 
				fclose(ptr)  ; 
				remove("urunler.dat") ; 
				rename("yedek.dat", "urunler.dat" ) ; 				
				system("cls") ; 				
	 			printf("\n%d numarali urun kaydi silindi  \n", numara ); 
		
			}
			else 
			printf("\nSilme islemi iptal edildi \n") ; 
			
		}		
	 } 
	fclose(ptr) ; 
	
	
	
	
}
int  urunMenu()
{
	int secim; 
	printf("\n\tUrun Islemleri \n\n") ; 
	printf("\t1- Urun Ekle  \n");
	printf("\t2- Urun Listele  \n");
	printf("\t3- Urun Guncelle  \n");
	printf("\t4- Urun Sil \n");
	
	printf("\t0- Anamenuye don \n") ; 
	printf("\n\tSeciminiz  :  ") ; scanf("%d", &secim); 
	system("cls"); 
	return secim;
}
void urunIslemleri()
{
	int secim= urunMenu(); 
	while( secim != 0)
	{
		switch(secim )
		{
			case 1: urunEkle() ; break;
			case 2: urunListele() ; break;
			case 3: urunGuncelle () ; break;
			case 4: urunSil ( ) ; break;
			
			case 0: printf("Anamenuye yonlendiriyorsunuz... ") ; break; 
			default: printf("hatali islem ! \n") ; break; 
		}
		secim= urunMenu(); 
	} 	
}

