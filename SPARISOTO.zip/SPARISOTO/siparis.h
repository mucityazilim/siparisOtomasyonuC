#ifndef _SIPARIS_H
#define _SIPARIS_H



typedef struct Siparis {
	int ID, mID, uID, adet, toplamUcret;
	char tarih [30]; 
	
} siparis ;

int musteriKontrolu(int ); 
int urunKontrolu(int, int  ); 

void urunStokGuncelle(int, int ); 

void siparisOlustur(); 
void siparisIptalet (); 

void siparisleriRaporla (); 

int  siparisMenu(); 
void siparisIslemleri(); 


#endif 
