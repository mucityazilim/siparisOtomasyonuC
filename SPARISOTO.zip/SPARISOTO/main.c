#include <stdio.h>
#include <stdlib.h>
#include "musteri.h"
#include "urun.h"
#include "siparis.h"

// S�PAR�� OTOMASYONU  
// MOD�LER C YAPISI �LE 
int menu() 
{
	int secim; 
	printf("\n\tSIPARIS OTOMASYONU \n\n") ; 
	printf("\t1- MUSTERI ISLEMLERI \n"); 
	printf("\t2- URUN ISLEMLERI \n" ) ; 
	printf("\t3- SIPARIS ISLEMLERI \n") ; 
	printf("\t0- CIKIS \n") ; 
	printf("\n\tSeciminiz  :  ") ; scanf("%d", &secim); 
	system("cls"); 
	return secim;	 
}

int main(int argc, char *argv[]) {
	
	int secim= menu(); 
	while( secim != 0)
	{
		switch(secim )
		{
			case 1: musteriIslemleri() ; break; 
			case 2: urunIslemleri(); break; 
			case 3: siparisIslemleri(); break ; 
			case 0: break; 
			default: printf("hatali islem ! \n") ; break; 
		}
		secim= menu(); 
	}
	
	
	return 0;
}
